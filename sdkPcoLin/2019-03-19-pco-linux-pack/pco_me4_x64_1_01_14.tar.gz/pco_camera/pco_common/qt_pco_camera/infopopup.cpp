#include "infopopup.h"

InfoPopup::InfoPopup(QWidget *parent)
    : QDialog(parent)
{
    setupUi(this);
}

InfoPopup::~InfoPopup()
{

}
